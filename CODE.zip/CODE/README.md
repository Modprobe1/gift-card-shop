# 🔐 Система регистрации и авторизации

Полноценная система регистрации и авторизации пользователей с React фронтендом и Go бэкендом.

## 🚀 Быстрый старт

### С помощью Docker (рекомендуется)
```bash
./setup.sh
```

### Локальный запуск
См. [LOCAL_SETUP.md](LOCAL_SETUP.md) для подробных инструкций.

## 📁 Структура проекта

```
├── frontend/          # React приложение
│   ├── src/
│   │   ├── components/    # React компоненты
│   │   ├── contexts/      # React контексты
│   │   ├── services/      # API сервисы
│   │   └── types/         # TypeScript типы
│   ├── public/            # Статические файлы
│   └── package.json       # Зависимости
├── backend/           # Go сервер
│   ├── controllers/   # HTTP контроллеры
│   ├── services/      # Бизнес-логика
│   ├── models/        # Модели данных
│   ├── middleware/    # HTTP middleware
│   ├── utils/         # Утилиты
│   ├── config/        # Конфигурация
│   └── main.go        # Точка входа
├── docker-compose.yml # Docker конфигурация
├── setup.sh          # Скрипт запуска
└── README.md         # Документация
```

## 🛠 Технологии

### Frontend
- **React 18** - UI библиотека
- **TypeScript** - Типизированный JavaScript
- **Axios** - HTTP клиент
- **React Router** - Маршрутизация
- **Tailwind CSS** - CSS фреймворк

### Backend
- **Go 1.21+** - Язык программирования
- **Gin** - HTTP фреймворк
- **JWT** - JSON Web Tokens
- **bcrypt** - Хеширование паролей
- **MongoDB** - NoSQL база данных
- **Logrus** - Логирование

## 🔧 API Endpoints

| Метод | Путь | Описание | Аутентификация |
|-------|------|----------|----------------|
| `POST` | `/api/register` | Регистрация пользователя | ❌ |
| `POST` | `/api/login` | Авторизация пользователя | ❌ |
| `GET` | `/api/profile` | Получение профиля | ✅ |
| `PUT` | `/api/profile` | Обновление профиля | ✅ |
| `GET` | `/health` | Проверка здоровья | ❌ |

## ✨ Функциональность

### 🔐 Аутентификация
- ✅ Регистрация пользователей с валидацией
- ✅ Авторизация с JWT токенами
- ✅ Хеширование паролей (bcrypt)
- ✅ Защищенные маршруты
- ✅ Автоматический logout при истечении токена

### 🛡️ Безопасность
- ✅ Валидация входных данных
- ✅ CORS настройки
- ✅ Безопасные HTTP заголовки
- ✅ Защита от SQL инъекций (MongoDB)
- ✅ Rate limiting (готов к добавлению)

### 📊 Логирование
- ✅ Логирование всех HTTP запросов
- ✅ Логирование ошибок аутентификации
- ✅ Структурированные JSON логи
- ✅ Настраиваемые уровни логирования

### 🎨 UI/UX
- ✅ Современный адаптивный дизайн
- ✅ Переключение между формами входа/регистрации
- ✅ Валидация форм в реальном времени
- ✅ Обработка ошибок с пользовательскими сообщениями
- ✅ Загрузочные состояния

## 🚀 Запуск

### Docker (рекомендуется)
```bash
# Клонирование репозитория
git clone <repository-url>
cd auth-system

# Запуск всех сервисов
./setup.sh

# Проверка статуса
docker-compose ps
```

### Локальный запуск
```bash
# 1. Запуск MongoDB
sudo systemctl start mongod

# 2. Запуск Backend
cd backend
go mod tidy
go run main.go

# 3. Запуск Frontend (в новом терминале)
cd frontend
npm install
npm start
```

## 🌐 Доступ к приложению

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8080
- **MongoDB**: localhost:27017

## 🧪 Тестирование

См. [API_TESTS.md](API_TESTS.md) для примеров тестирования API.

### Быстрое тестирование
```bash
# Проверка здоровья сервиса
curl http://localhost:8080/health

# Регистрация пользователя
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","firstName":"Иван","lastName":"Иванов"}'
```

## 📝 Конфигурация

### Переменные окружения

#### Backend (.env)
```env
MONGODB_URI=mongodb://localhost:27017/auth_db
JWT_SECRET=your-super-secret-jwt-key-change-in-production
PORT=8080
LOG_LEVEL=info
```

#### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:8080
```

## 🔍 Мониторинг

### Логи
```bash
# Docker логи
docker-compose logs -f

# Backend логи
docker-compose logs -f backend

# Frontend логи
docker-compose logs -f frontend
```

### Статус сервисов
```bash
docker-compose ps
```

## 🛠 Разработка

### Структура кода
- **Clean Architecture** - разделение на слои
- **Dependency Injection** - внедрение зависимостей
- **Repository Pattern** - работа с базой данных
- **Middleware Pattern** - обработка запросов

### Добавление новых функций
1. Создать модель в `backend/models/`
2. Добавить сервис в `backend/services/`
3. Создать контроллер в `backend/controllers/`
4. Добавить маршрут в `main.go`
5. Создать компонент в `frontend/src/components/`

## 🤝 Вклад в проект

1. Fork репозитория
2. Создать feature branch
3. Внести изменения
4. Добавить тесты
5. Создать Pull Request

## 📄 Лицензия

MIT License - см. файл LICENSE для деталей.

## 🆘 Поддержка

При возникновении проблем:
1. Проверьте логи: `docker-compose logs`
2. Убедитесь, что все порты свободны
3. Проверьте подключение к MongoDB
4. Создайте Issue в репозитории 
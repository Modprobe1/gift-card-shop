# 🚀 Быстрый старт

## Вариант 1: Docker (рекомендуется)

```bash
# 1. Убедитесь, что Docker установлен
docker --version
docker-compose --version

# 2. Запустите проект
./setup.sh

# 3. Откройте браузер
open http://localhost:3000
```

## Вариант 2: Локальный запуск

### Предварительные требования
- Go 1.21+
- Node.js 18+
- MongoDB

### Запуск
```bash
# 1. Запустите MongoDB
sudo systemctl start mongod

# 2. Запустите Backend (в одном терминале)
cd backend
go mod tidy
go run main.go

# 3. Запустите Frontend (в другом терминале)
cd frontend
npm install
npm start

# 4. Откройте браузер
open http://localhost:3000
```

## 🎯 Что вы получите

✅ **Форма регистрации** - создание нового аккаунта
✅ **Форма входа** - авторизация существующих пользователей  
✅ **Профиль пользователя** - просмотр и редактирование данных
✅ **Безопасность** - хеширование паролей, JWT токены
✅ **Логирование** - все операции записываются в логи
✅ **Современный UI** - красивый адаптивный интерфейс

## 🔧 Тестирование

```bash
# Проверка API
curl http://localhost:8080/health

# Регистрация пользователя
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","firstName":"Иван","lastName":"Иванов"}'
```

## 📚 Документация

- [Полная документация](README.md)
- [Локальная настройка](LOCAL_SETUP.md)
- [Тестирование API](API_TESTS.md)

## 🆘 Проблемы?

1. Проверьте логи: `docker-compose logs`
2. Убедитесь, что порты 3000, 8080, 27017 свободны
3. Проверьте подключение к MongoDB
4. Создайте Issue в репозитории 
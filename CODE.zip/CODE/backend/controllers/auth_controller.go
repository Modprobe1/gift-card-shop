package controllers

import (
	"net/http"

	"auth-backend/config"
	"auth-backend/models"
	"auth-backend/services"
	"auth-backend/utils"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"github.com/sirupsen/logrus"
)

// AuthController обрабатывает запросы авторизации
type AuthController struct {
	userService *services.UserService
	config      *config.Config
	logger      *logrus.Logger
	validate    *validator.Validate
}

// NewAuthController создает новый экземпляр AuthController
func NewAuthController(userService *services.UserService, config *config.Config, logger *logrus.Logger) *AuthController {
	return &AuthController{
		userService: userService,
		config:      config,
		logger:      logger,
		validate:    validator.New(),
	}
}

// Register обрабатывает запрос на регистрацию
func (ac *AuthController) Register(c *gin.Context) {
	var req models.RegisterRequest

	if err := c.ShouldBindJSON(&req); err != nil {
		ac.logger.WithError(err).Error("Failed to bind register request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request data"})
		return
	}

	// Валидируем данные
	if err := ac.validate.Struct(req); err != nil {
		ac.logger.WithError(err).Error("Validation failed for register request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Validation failed", "details": err.Error()})
		return
	}

	// Создаем пользователя
	user := &models.User{
		Email:     req.Email,
		Password:  req.Password,
		FirstName: req.FirstName,
		LastName:  req.LastName,
	}

	if err := ac.userService.CreateUser(user); err != nil {
		ac.logger.WithError(err).WithField("email", req.Email).Error("Failed to create user")
		c.JSON(http.StatusConflict, gin.H{"error": err.Error()})
		return
	}

	// Генерируем JWT токен
	token, err := utils.GenerateJWT(user.ID.Hex(), user.Email, ac.config.JWTSecret)
	if err != nil {
		ac.logger.WithError(err).Error("Failed to generate JWT token")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	ac.logger.WithField("email", user.Email).Info("User registered successfully")

	c.JSON(http.StatusCreated, models.AuthResponse{
		Token: token,
		User:  user.ToResponse(),
	})
}

// Login обрабатывает запрос на авторизацию
func (ac *AuthController) Login(c *gin.Context) {
	var req models.LoginRequest

	if err := c.ShouldBindJSON(&req); err != nil {
		ac.logger.WithError(err).Error("Failed to bind login request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request data"})
		return
	}

	// Валидируем данные
	if err := ac.validate.Struct(req); err != nil {
		ac.logger.WithError(err).Error("Validation failed for login request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Validation failed", "details": err.Error()})
		return
	}

	// Получаем пользователя по email
	user, err := ac.userService.GetUserByEmail(req.Email)
	if err != nil {
		ac.logger.WithError(err).WithField("email", req.Email).Error("User not found")
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Проверяем пароль
	if !utils.CheckPasswordHash(req.Password, user.Password) {
		ac.logger.WithField("email", req.Email).Error("Invalid password")
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Генерируем JWT токен
	token, err := utils.GenerateJWT(user.ID.Hex(), user.Email, ac.config.JWTSecret)
	if err != nil {
		ac.logger.WithError(err).Error("Failed to generate JWT token")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	ac.logger.WithField("email", user.Email).Info("User logged in successfully")

	c.JSON(http.StatusOK, models.AuthResponse{
		Token: token,
		User:  user.ToResponse(),
	})
}

// GetProfile получает профиль текущего пользователя
func (ac *AuthController) GetProfile(c *gin.Context) {
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	user, err := ac.userService.GetUserByID(userID.(string))
	if err != nil {
		ac.logger.WithError(err).WithField("userID", userID).Error("Failed to get user profile")
		c.JSON(http.StatusNotFound, gin.H{"error": "User not found"})
		return
	}

	c.JSON(http.StatusOK, user.ToResponse())
}

// UpdateProfile обновляет профиль пользователя
func (ac *AuthController) UpdateProfile(c *gin.Context) {
	userID, exists := c.Get("userID")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	var req struct {
		FirstName string `json:"firstName" validate:"required,min=2"`
		LastName  string `json:"lastName" validate:"required,min=2"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		ac.logger.WithError(err).Error("Failed to bind update profile request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request data"})
		return
	}

	// Валидируем данные
	if err := ac.validate.Struct(req); err != nil {
		ac.logger.WithError(err).Error("Validation failed for update profile request")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Validation failed", "details": err.Error()})
		return
	}

	// Обновляем пользователя
	updates := map[string]interface{}{
		"firstName": req.FirstName,
		"lastName":  req.LastName,
	}

	if err := ac.userService.UpdateUser(userID.(string), updates); err != nil {
		ac.logger.WithError(err).WithField("userID", userID).Error("Failed to update user profile")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update profile"})
		return
	}

	// Получаем обновленного пользователя
	user, err := ac.userService.GetUserByID(userID.(string))
	if err != nil {
		ac.logger.WithError(err).WithField("userID", userID).Error("Failed to get updated user profile")
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get updated profile"})
		return
	}

	ac.logger.WithField("userID", userID).Info("User profile updated successfully")

	c.JSON(http.StatusOK, user.ToResponse())
}

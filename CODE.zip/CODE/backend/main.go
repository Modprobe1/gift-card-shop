package main

import (
	"context"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"auth-backend/config"
	"auth-backend/controllers"
	"auth-backend/middleware"
	"auth-backend/services"

	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func main() {
	// Загружаем конфигурацию
	cfg := config.LoadConfig()

	// Настраиваем логирование
	logger := logrus.New()
	logger.SetFormatter(&logrus.JSONFormatter{})
	logger.SetOutput(os.Stdout)

	// Устанавливаем уровень логирования
	level, err := logrus.ParseLevel(cfg.LogLevel)
	if err != nil {
		logger.WithError(err).Fatal("Failed to parse log level")
	}
	logger.SetLevel(level)

	logger.Info("Starting authentication service...")

	// Подключаемся к MongoDB
	client, err := mongo.Connect(context.Background(), options.Client().ApplyURI(cfg.MongoURI))
	if err != nil {
		logger.WithError(err).Fatal("Failed to connect to MongoDB")
	}
	defer func() {
		if err := client.Disconnect(context.Background()); err != nil {
			logger.WithError(err).Error("Failed to disconnect from MongoDB")
		}
	}()

	// Проверяем подключение к базе данных
	if err := client.Ping(context.Background(), nil); err != nil {
		logger.WithError(err).Fatal("Failed to ping MongoDB")
	}

	logger.Info("Successfully connected to MongoDB")

	// Получаем базу данных
	db := client.Database("auth_db")

	// Создаем сервисы
	userService := services.NewUserService(db)

	// Создаем индексы
	if err := userService.CreateIndexes(); err != nil {
		logger.WithError(err).Error("Failed to create indexes")
	}

	// Создаем контроллеры
	authController := controllers.NewAuthController(userService, cfg, logger)

	// Настраиваем Gin
	gin.SetMode(gin.ReleaseMode)
	router := gin.New()

	// Добавляем middleware
	router.Use(middleware.CORSMiddleware())
	router.Use(middleware.LoggingMiddleware(logger))
	router.Use(gin.Recovery())

	// Настраиваем маршруты
	api := router.Group("/api")
	{
		// Публичные маршруты
		api.POST("/register", authController.Register)
		api.POST("/login", authController.Login)

		// Защищенные маршруты
		protected := api.Group("/")
		protected.Use(middleware.AuthMiddleware(cfg))
		{
			protected.GET("/profile", authController.GetProfile)
			protected.PUT("/profile", authController.UpdateProfile)
		}
	}

	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "timestamp": time.Now()})
	})

	// Создаем HTTP сервер
	srv := &http.Server{
		Addr:    ":" + cfg.Port,
		Handler: router,
	}

	// Запускаем сервер в горутине
	go func() {
		logger.WithField("port", cfg.Port).Info("Starting HTTP server")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.WithError(err).Fatal("Failed to start server")
		}
	}()

	// Ждем сигнала для graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("Shutting down server...")

	// Graceful shutdown
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		logger.WithError(err).Error("Server forced to shutdown")
	}

	logger.Info("Server exited")
}

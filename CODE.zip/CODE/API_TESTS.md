# Тестирование API

## Запуск проекта

```bash
./setup.sh
```

## Тестирование с помощью curl

### 1. Регистрация пользователя

```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Иван",
    "lastName": "Иванов"
  }'
```

**Ожидаемый ответ:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "email": "test@example.com",
    "firstName": "Иван",
    "lastName": "Иванов",
    "createdAt": "2023-09-06T10:30:00Z",
    "updatedAt": "2023-09-06T10:30:00Z"
  }
}
```

### 2. Авторизация пользователя

```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
```

**Ожидаемый ответ:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "64f8a1b2c3d4e5f6a7b8c9d0",
    "email": "test@example.com",
    "firstName": "Иван",
    "lastName": "Иванов",
    "createdAt": "2023-09-06T10:30:00Z",
    "updatedAt": "2023-09-06T10:30:00Z"
  }
}
```

### 3. Получение профиля (требует токен)

```bash
curl -X GET http://localhost:8080/api/profile \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

### 4. Обновление профиля (требует токен)

```bash
curl -X PUT http://localhost:8080/api/profile \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "firstName": "Петр",
    "lastName": "Петров"
  }'
```

### 5. Проверка здоровья сервиса

```bash
curl -X GET http://localhost:8080/health
```

**Ожидаемый ответ:**
```json
{
  "status": "ok",
  "timestamp": "2023-09-06T10:30:00Z"
}
```

## Тестирование ошибок

### Неверный пароль

```bash
curl -X POST http://localhost:8080/api/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "wrongpassword"
  }'
```

**Ожидаемый ответ:**
```json
{
  "error": "Invalid credentials"
}
```

### Пользователь уже существует

```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Иван",
    "lastName": "Иванов"
  }'
```

**Ожидаемый ответ:**
```json
{
  "error": "user with this email already exists"
}
```

### Неверный токен

```bash
curl -X GET http://localhost:8080/api/profile \
  -H "Authorization: Bearer invalid_token"
```

**Ожидаемый ответ:**
```json
{
  "error": "Invalid token"
}
```

## Тестирование с помощью Postman

1. Импортируйте коллекцию в Postman
2. Установите переменную окружения `base_url` = `http://localhost:8080`
3. После регистрации/входа сохраните токен в переменную `token`
4. Используйте `{{base_url}}` и `{{token}}` в запросах

## Логирование

Все запросы логируются в контейнере backend:

```bash
docker-compose logs -f backend
```

Логи включают:
- HTTP запросы с методом, путем, статусом и временем выполнения
- Ошибки валидации
- Успешные операции регистрации и входа
- Ошибки аутентификации 
# ⚡ Быстрое развертывание на сервере

## 🎯 Что нужно сделать

### 1. Подготовка SSL сертификатов
```bash
# Создайте директорию для SSL
mkdir -p nginx/ssl

# Скопируйте ваши сертификаты
cp /path/to/your/certificate.crt nginx/ssl/booleanlcfg.store.crt
cp /path/to/your/private.key nginx/ssl/booleanlcfg.store.key

# Установите правильные права
chmod 644 nginx/ssl/booleanlcfg.store.crt
chmod 600 nginx/ssl/booleanlcfg.store.key
```

### 2. Запуск развертывания
```bash
# Сделайте скрипт исполняемым
chmod +x deploy.sh

# Запустите развертывание
./deploy.sh
```

### 3. Проверка
```bash
# Проверьте статус контейнеров
docker-compose -f docker-compose.prod.yml ps

# Проверьте доступность
curl https://booleanlcfg.store/health
```

## 🔧 Ответы на ваши вопросы

### ❓ Можно ли использовать setup.sh?
**НЕТ** - `setup.sh` предназначен для локальной разработки. Для сервера используйте `deploy.sh`.

### ❓ Что изменилось для продакшена?
- ✅ Добавлен Nginx с SSL поддержкой
- ✅ Настроен CORS для вашего домена
- ✅ Добавлено rate limiting
- ✅ Настроены безопасные заголовки
- ✅ Добавлено логирование
- ✅ Автоматический restart контейнеров

### ❓ Какие порты используются?
- **80** - HTTP (редирект на HTTPS)
- **443** - HTTPS (основной трафик)
- **8080** - Backend API (внутренний)
- **3000** - Frontend (внутренний)
- **27017** - MongoDB (внутренний)

## 🚀 Команды управления

```bash
# Запуск
./deploy.sh

# Остановка
docker-compose -f docker-compose.prod.yml down

# Перезапуск
docker-compose -f docker-compose.prod.yml restart

# Логи
docker-compose -f docker-compose.prod.yml logs -f

# Статус
docker-compose -f docker-compose.prod.yml ps
```

## 🔍 Проверка работы

После развертывания проверьте:

1. **Frontend**: https://booleanlcfg.store
2. **Backend API**: https://booleanlcfg.store/health
3. **Регистрация**: https://booleanlcfg.store (форма регистрации)
4. **Вход**: https://booleanlcfg.store (форма входа)

## 🆘 Если что-то не работает

1. **Проверьте логи**:
   ```bash
   docker-compose -f docker-compose.prod.yml logs
   ```

2. **Проверьте SSL сертификаты**:
   ```bash
   ls -la nginx/ssl/
   ```

3. **Проверьте порты**:
   ```bash
   sudo netstat -tlnp | grep -E ':(80|443)'
   ```

4. **Проверьте DNS**:
   ```bash
   nslookup booleanlcfg.store
   ```

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи
2. Убедитесь, что SSL сертификаты на месте
3. Проверьте, что порты 80 и 443 открыты
4. Создайте Issue с подробным описанием 
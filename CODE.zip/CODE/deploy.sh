#!/bin/bash

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1${NC}"
}

# Проверка наличия Docker
check_docker() {
    if ! command -v docker &> /dev/null; then
        error "Docker не установлен"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        error "Docker Compose не установлен"
        exit 1
    fi
    
    log "Docker и Docker Compose найдены"
}

# Создание .env файла
create_env() {
    if [ ! -f .env ]; then
        log "Создаем .env файл..."
        cat > .env << EOF
# MongoDB
MONGO_PASSWORD=$(openssl rand -base64 32)

# JWT Secret
JWT_SECRET=$(openssl rand -base64 64)

# Domain
DOMAIN=booleanlcfg.store

# Environment
NODE_ENV=production
EOF
        log "✅ .env файл создан"
    else
        warn ".env файл уже существует"
    fi
}

# Создание директорий
create_directories() {
    log "Создаем необходимые директории..."
    
    mkdir -p nginx/ssl
    mkdir -p nginx/sites-available
    mkdir -p logs/nginx
    mkdir -p logs/backend
    mkdir -p mongo-init
    
    log "✅ Директории созданы"
}

# Проверка SSL сертификатов
check_ssl() {
    log "Проверяем SSL сертификаты..."
    
    if [ ! -f "nginx/ssl/booleanlcfg.store.crt" ] || [ ! -f "nginx/ssl/booleanlcfg.store.key" ]; then
        error "SSL сертификаты не найдены в nginx/ssl/"
        error "Пожалуйста, поместите ваши сертификаты:"
        error "  - nginx/ssl/booleanlcfg.store.crt"
        error "  - nginx/ssl/booleanlcfg.store.key"
        exit 1
    fi
    
    log "✅ SSL сертификаты найдены"
}

# Остановка существующих контейнеров
stop_containers() {
    log "Останавливаем существующие контейнеры..."
    docker-compose -f docker-compose.prod.yml down --remove-orphans
    log "✅ Контейнеры остановлены"
}

# Сборка и запуск
build_and_start() {
    log "Собираем и запускаем контейнеры..."
    
    # Сборка образов
    docker-compose -f docker-compose.prod.yml build --no-cache
    
    # Запуск в фоновом режиме
    docker-compose -f docker-compose.prod.yml up -d
    
    log "✅ Контейнеры запущены"
}

# Проверка статуса
check_status() {
    log "Проверяем статус сервисов..."
    sleep 10
    
    # Проверка контейнеров
    docker-compose -f docker-compose.prod.yml ps
    
    # Проверка доступности
    log "Проверяем доступность сервисов..."
    
    # Проверка backend
    if curl -f -s https://booleanlcfg.store/health > /dev/null; then
        log "✅ Backend доступен"
    else
        warn "⚠️  Backend недоступен (возможно, еще запускается)"
    fi
    
    # Проверка frontend
    if curl -f -s https://booleanlcfg.store > /dev/null; then
        log "✅ Frontend доступен"
    else
        warn "⚠️  Frontend недоступен (возможно, еще запускается)"
    fi
}

# Основная функция
main() {
    log "🚀 Начинаем развертывание на продакшене..."
    
    check_docker
    create_env
    create_directories
    check_ssl
    stop_containers
    build_and_start
    check_status
    
    log "🎉 Развертывание завершено!"
    log ""
    log "📱 Ваше приложение доступно по адресу:"
    log "   https://booleanlcfg.store"
    log ""
    log "📋 Полезные команды:"
    log "   docker-compose -f docker-compose.prod.yml logs -f    # Просмотр логов"
    log "   docker-compose -f docker-compose.prod.yml down      # Остановка"
    log "   docker-compose -f docker-compose.prod.yml restart   # Перезапуск"
    log ""
    log "🔍 Мониторинг:"
    log "   docker-compose -f docker-compose.prod.yml ps        # Статус контейнеров"
    log "   docker stats                                        # Статистика ресурсов"
    log ""
}

# Запуск основной функции
main "$@" 
# 🚀 Развертывание на сервере

## Подготовка сервера

### 1. Подключение к серверу
```bash
ssh your-username@your-server-ip
```

### 2. Обновление системы
```bash
sudo apt update && sudo apt upgrade -y
```

### 3. Установка необходимых пакетов
```bash
sudo apt install -y curl wget git unzip
```

### 4. Установка Docker (если не установлен)
```bash
# Удаление старых версий
sudo apt remove docker docker-engine docker.io containerd runc

# Установка зависимостей
sudo apt install -y apt-transport-https ca-certificates curl gnupg lsb-release

# Добавление GPG ключа Docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Добавление репозитория Docker
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Установка Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Добавление пользователя в группу docker
sudo usermod -aG docker $USER
```

### 5. Перезагрузка (для применения изменений группы)
```bash
sudo reboot
```

## Развертывание приложения

### 1. Клонирование проекта
```bash
git clone <your-repository-url>
cd auth-system
```

### 2. Подготовка SSL сертификатов
```bash
# Создание директории для SSL
mkdir -p nginx/ssl

# Копирование ваших SSL сертификатов
# Замените на ваши реальные пути к сертификатам
sudo cp /path/to/your/certificate.crt nginx/ssl/booleanlcfg.store.crt
sudo cp /path/to/your/private.key nginx/ssl/booleanlcfg.store.key

# Установка правильных прав доступа
sudo chmod 644 nginx/ssl/booleanlcfg.store.crt
sudo chmod 600 nginx/ssl/booleanlcfg.store.key
```

### 3. Настройка файрвола
```bash
# Установка UFW
sudo apt install -y ufw

# Настройка правил
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable

# Проверка статуса
sudo ufw status
```

### 4. Запуск развертывания
```bash
# Сделать скрипт исполняемым
chmod +x deploy.sh

# Запустить развертывание
./deploy.sh
```

## Проверка развертывания

### 1. Проверка контейнеров
```bash
docker-compose -f docker-compose.prod.yml ps
```

### 2. Проверка логов
```bash
# Все логи
docker-compose -f docker-compose.prod.yml logs

# Логи конкретного сервиса
docker-compose -f docker-compose.prod.yml logs backend
docker-compose -f docker-compose.prod.yml logs frontend
docker-compose -f docker-compose.prod.yml logs nginx
```

### 3. Проверка доступности
```bash
# Проверка backend
curl -k https://booleanlcfg.store/health

# Проверка frontend
curl -k https://booleanlcfg.store
```

## Управление приложением

### Остановка
```bash
docker-compose -f docker-compose.prod.yml down
```

### Перезапуск
```bash
docker-compose -f docker-compose.prod.yml restart
```

### Обновление
```bash
# Остановка
docker-compose -f docker-compose.prod.yml down

# Обновление кода
git pull

# Пересборка и запуск
docker-compose -f docker-compose.prod.yml build --no-cache
docker-compose -f docker-compose.prod.yml up -d
```

### Просмотр логов в реальном времени
```bash
docker-compose -f docker-compose.prod.yml logs -f
```

## Мониторинг

### 1. Статистика контейнеров
```bash
docker stats
```

### 2. Использование диска
```bash
df -h
docker system df
```

### 3. Мониторинг логов
```bash
# Nginx логи
tail -f logs/nginx/access.log
tail -f logs/nginx/error.log

# Backend логи
tail -f logs/backend/app.log
```

## Резервное копирование

### 1. Резервное копирование базы данных
```bash
# Создание бэкапа
docker exec auth_mongodb_prod mongodump --out /data/backup

# Копирование бэкапа с контейнера
docker cp auth_mongodb_prod:/data/backup ./backup_$(date +%Y%m%d_%H%M%S)
```

### 2. Восстановление базы данных
```bash
# Копирование бэкапа в контейнер
docker cp ./backup_20231201_120000 auth_mongodb_prod:/data/

# Восстановление
docker exec auth_mongodb_prod mongorestore /data/backup_20231201_120000
```

## Устранение неполадок

### 1. Проблемы с SSL
```bash
# Проверка сертификатов
openssl x509 -in nginx/ssl/booleanlcfg.store.crt -text -noout

# Проверка конфигурации Nginx
docker exec auth_nginx_prod nginx -t
```

### 2. Проблемы с базой данных
```bash
# Подключение к MongoDB
docker exec -it auth_mongodb_prod mongosh

# Проверка подключения
docker exec auth_backend_prod curl -f http://mongodb:27017
```

### 3. Проблемы с сетью
```bash
# Проверка портов
sudo netstat -tlnp | grep -E ':(80|443|8080|3000|27017)'

# Проверка DNS
nslookup booleanlcfg.store
```

### 4. Проблемы с памятью
```bash
# Очистка неиспользуемых образов
docker system prune -a

# Очистка логов
docker system prune -f
```

## Автоматическое обновление

### Создание cron задачи для автоматического обновления
```bash
# Открыть crontab
crontab -e

# Добавить задачу (обновление каждый день в 3:00)
0 3 * * * cd /path/to/auth-system && git pull && docker-compose -f docker-compose.prod.yml up -d --build
```

## Безопасность

### 1. Регулярное обновление системы
```bash
# Автоматические обновления безопасности
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

### 2. Мониторинг безопасности
```bash
# Установка fail2ban
sudo apt install fail2ban

# Настройка для SSH
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 3. Регулярные бэкапы
```bash
# Создание скрипта для автоматических бэкапов
cat > backup.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/auth-system"

mkdir -p $BACKUP_DIR

# Бэкап базы данных
docker exec auth_mongodb_prod mongodump --out /data/backup
docker cp auth_mongodb_prod:/data/backup $BACKUP_DIR/mongodb_$DATE

# Бэкап конфигурации
tar -czf $BACKUP_DIR/config_$DATE.tar.gz nginx/ .env

# Удаление старых бэкапов (старше 30 дней)
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
find $BACKUP_DIR -name "mongodb_*" -mtime +30 -exec rm -rf {} \;
EOF

chmod +x backup.sh
```

## Контакты для поддержки

При возникновении проблем:
1. Проверьте логи: `docker-compose -f docker-compose.prod.yml logs`
2. Проверьте статус контейнеров: `docker-compose -f docker-compose.prod.yml ps`
3. Проверьте использование ресурсов: `docker stats`
4. Создайте Issue в репозитории с подробным описанием проблемы 
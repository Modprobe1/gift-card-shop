#!/bin/bash

echo "🚀 Настройка системы регистрации и авторизации..."

# Проверяем наличие Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker не установлен. Пожалуйста, установите Docker."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose не установлен. Пожалуйста, установите Docker Compose."
    exit 1
fi

echo "✅ Docker и Docker Compose найдены"

# Создаем .env файл если его нет
if [ ! -f .env ]; then
    echo "📝 Создаем .env файл..."
    cat > .env << EOF
# MongoDB
MONGO_INITDB_ROOT_USERNAME=admin
MONGO_INITDB_ROOT_PASSWORD=password
MONGODB_URI=mongodb://admin:password@mongodb:27017/auth_db?authSource=admin

# Backend
JWT_SECRET=your-super-secret-jwt-key-change-in-production
PORT=8080
LOG_LEVEL=info

# Frontend
REACT_APP_API_URL=http://localhost:8080
EOF
    echo "✅ .env файл создан"
fi

echo "🔧 Запускаем проект с помощью Docker Compose..."
docker-compose up --build -d

echo "⏳ Ждем запуска сервисов..."
sleep 10

echo "🔍 Проверяем статус сервисов..."
docker-compose ps

echo ""
echo "🎉 Проект успешно запущен!"
echo ""
echo "📱 Frontend: http://localhost:3000"
echo "🔧 Backend API: http://localhost:8080"
echo "🗄️  MongoDB: localhost:27017"
echo ""
echo "📋 Доступные команды:"
echo "  docker-compose logs -f    # Просмотр логов"
echo "  docker-compose down       # Остановить проект"
echo "  docker-compose restart    # Перезапустить проект"
echo ""
echo "🔐 Теперь вы можете:"
echo "  1. Открыть http://localhost:3000 в браузере"
echo "  2. Зарегистрировать нового пользователя"
echo "  3. Войти в систему"
echo "  4. Просматривать и редактировать профиль"
echo "" 
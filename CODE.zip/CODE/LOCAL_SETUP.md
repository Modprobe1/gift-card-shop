# Локальная настройка без Docker

## Предварительные требования

### 1. Установка Go (1.21+)
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install golang-go

# CentOS/RHEL
sudo yum install golang

# macOS
brew install go

# Проверка версии
go version
```

### 2. Установка Node.js (18+)
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# CentOS/RHEL
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# macOS
brew install node

# Проверка версии
node --version
npm --version
```

### 3. Установка MongoDB
```bash
# Ubuntu/Debian
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org

# CentOS/RHEL
cat > /etc/yum.repos.d/mongodb-org-6.0.repo << EOF
[mongodb-org-6.0]
name=MongoDB Repository
baseurl=https://repo.mongodb.org/yum/redhat/\$releasever/mongodb-org/6.0/x86_64/
gpgcheck=1
enabled=1
gpgkey=https://www.mongodb.org/static/pgp/server-6.0.asc
EOF
sudo yum install -y mongodb-org

# macOS
brew tap mongodb/brew
brew install mongodb-community

# Запуск MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
```

## Запуск проекта

### 1. Запуск MongoDB
```bash
# Запуск MongoDB сервиса
sudo systemctl start mongod

# Проверка статуса
sudo systemctl status mongod
```

### 2. Настройка и запуск Backend

```bash
cd backend

# Установка зависимостей
go mod tidy

# Создание .env файла
cat > .env << EOF
MONGODB_URI=mongodb://localhost:27017/auth_db
JWT_SECRET=your-super-secret-jwt-key-change-in-production
PORT=8080
LOG_LEVEL=info
EOF

# Запуск backend
go run main.go
```

Backend будет доступен по адресу: http://localhost:8080

### 3. Настройка и запуск Frontend

```bash
cd frontend

# Установка зависимостей
npm install

# Создание .env файла
cat > .env << EOF
REACT_APP_API_URL=http://localhost:8080
EOF

# Запуск frontend
npm start
```

Frontend будет доступен по адресу: http://localhost:3000

## Проверка работы

### 1. Проверка Backend API
```bash
# Проверка здоровья сервиса
curl http://localhost:8080/health

# Ожидаемый ответ:
# {"status":"ok","timestamp":"2023-09-06T10:30:00Z"}
```

### 2. Тестирование регистрации
```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "firstName": "Иван",
    "lastName": "Иванов"
  }'
```

### 3. Открытие Frontend
Откройте браузер и перейдите по адресу: http://localhost:3000

## Устранение неполадок

### MongoDB не запускается
```bash
# Проверка логов
sudo journalctl -u mongod

# Проверка порта
sudo netstat -tlnp | grep 27017

# Перезапуск сервиса
sudo systemctl restart mongod
```

### Backend не подключается к MongoDB
```bash
# Проверка подключения
mongo --eval "db.runCommand('ping')"

# Проверка базы данных
mongo auth_db --eval "db.stats()"
```

### Frontend не подключается к Backend
```bash
# Проверка CORS настроек
curl -H "Origin: http://localhost:3000" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: Content-Type" \
  -X OPTIONS http://localhost:8080/api/register
```

### Проблемы с портами
```bash
# Проверка занятых портов
sudo netstat -tlnp | grep -E ':(3000|8080|27017)'

# Остановка процессов на портах
sudo fuser -k 3000/tcp
sudo fuser -k 8080/tcp
```

## Остановка проекта

```bash
# Остановка frontend (Ctrl+C в терминале)
# Остановка backend (Ctrl+C в терминале)

# Остановка MongoDB
sudo systemctl stop mongod
```

## Логи

### Backend логи
Логи выводятся в консоль при запуске `go run main.go`

### MongoDB логи
```bash
sudo tail -f /var/log/mongodb/mongod.log
```

### Frontend логи
Логи выводятся в консоль при запуске `npm start` 
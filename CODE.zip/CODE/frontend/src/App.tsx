import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import Profile from './components/Profile';

// Компонент для защищенных маршрутов
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Загрузка...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

// Компонент навигации
const Navigation: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <nav className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/profile" className="text-xl font-bold text-gray-900">
              Аутентификация
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gray-700">
              Привет, {user.firstName}!
            </span>
            <button
              onClick={logout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
            >
              Выйти
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

// Компонент для переключения между формами
const AuthForms: React.FC = () => {
  const [isLogin, setIsLogin] = React.useState(true);

  return (
    <div>
      <div className="flex justify-center mb-8">
        <div className="bg-white rounded-lg shadow p-1">
          <button
            onClick={() => setIsLogin(true)}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              isLogin
                ? 'bg-indigo-600 text-white'
                : 'text-gray-700 hover:text-gray-900'
            }`}
          >
            Вход
          </button>
          <button
            onClick={() => setIsLogin(false)}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              !isLogin
                ? 'bg-indigo-600 text-white'
                : 'text-gray-700 hover:text-gray-900'
            }`}
          >
            Регистрация
          </button>
        </div>
      </div>
      {isLogin ? <LoginForm /> : <RegisterForm />}
    </div>
  );
};

// Главный компонент приложения
const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Загрузка...</div>;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <Routes>
          <Route
            path="/"
            element={
              user ? <Navigate to="/profile" replace /> : <AuthForms />
            }
          />
          <Route
            path="/login"
            element={
              user ? <Navigate to="/profile" replace /> : <AuthForms />
            }
          />
          <Route
            path="/register"
            element={
              user ? <Navigate to="/profile" replace /> : <AuthForms />
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
        </Routes>
      </div>
    </Router>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App; 
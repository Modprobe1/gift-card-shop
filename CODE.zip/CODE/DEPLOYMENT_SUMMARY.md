# 🚀 Сводка развертывания на сервере

## 📋 Что было создано для продакшена

### 🔧 Новые файлы
- `docker-compose.prod.yml` - Продакшен конфигурация Docker Compose
- `deploy.sh` - Скрипт автоматического развертывания
- `nginx/nginx.conf` - Основная конфигурация Nginx
- `nginx/sites-available/booleanlcfg.store.conf` - Конфигурация для вашего домена
- `SERVER_DEPLOYMENT.md` - Подробные инструкции по развертыванию
- `QUICK_DEPLOY.md` - Быстрая инструкция

### 🛡️ Безопасность
- ✅ SSL/TLS поддержка с вашими сертификатами
- ✅ Автоматический редирект HTTP → HTTPS
- ✅ Rate limiting для API endpoints
- ✅ Безопасные HTTP заголовки
- ✅ CORS настройки для вашего домена
- ✅ Защита от DDoS атак

### 📊 Мониторинг
- ✅ Логирование всех запросов
- ✅ Логирование ошибок
- ✅ Мониторинг контейнеров
- ✅ Статистика использования ресурсов

## 🎯 Пошаговый план развертывания

### 1. Подготовка сервера
```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Docker (если не установлен)
# См. SERVER_DEPLOYMENT.md для подробностей
```

### 2. Клонирование проекта
```bash
git clone <your-repository-url>
cd auth-system
```

### 3. Подготовка SSL сертификатов
```bash
mkdir -p nginx/ssl
cp /path/to/your/certificate.crt nginx/ssl/booleanlcfg.store.crt
cp /path/to/your/private.key nginx/ssl/booleanlcfg.store.key
chmod 644 nginx/ssl/booleanlcfg.store.crt
chmod 600 nginx/ssl/booleanlcfg.store.key
```

### 4. Запуск развертывания
```bash
chmod +x deploy.sh
./deploy.sh
```

### 5. Проверка
```bash
# Статус контейнеров
docker-compose -f docker-compose.prod.yml ps

# Проверка доступности
curl https://booleanlcfg.store/health
```

## 🔧 Архитектура продакшена

```
Internet
    ↓
Nginx (SSL/TLS, Load Balancer)
    ↓
├── Frontend (React) → Port 3000
├── Backend (Go) → Port 8080
└── MongoDB → Port 27017
```

### Потоки трафика
1. **Пользователь** → `https://booleanlcfg.store`
2. **Nginx** → Frontend (React приложение)
3. **Frontend** → Backend API (`/api/*`)
4. **Backend** → MongoDB (база данных)

## 📊 Мониторинг и управление

### Команды управления
```bash
# Запуск
./deploy.sh

# Остановка
docker-compose -f docker-compose.prod.yml down

# Перезапуск
docker-compose -f docker-compose.prod.yml restart

# Логи в реальном времени
docker-compose -f docker-compose.prod.yml logs -f

# Статус контейнеров
docker-compose -f docker-compose.prod.yml ps

# Статистика ресурсов
docker stats
```

### Логи
```bash
# Nginx логи
tail -f logs/nginx/access.log
tail -f logs/nginx/error.log

# Backend логи
docker-compose -f docker-compose.prod.yml logs backend

# Frontend логи
docker-compose -f docker-compose.prod.yml logs frontend
```

## 🔍 Проверка работоспособности

### Тестирование API
```bash
# Health check
curl https://booleanlcfg.store/health

# Регистрация пользователя
curl -X POST https://booleanlcfg.store/api/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","firstName":"Иван","lastName":"Иванов"}'

# Авторизация
curl -X POST https://booleanlcfg.store/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

### Проверка SSL
```bash
# Проверка сертификата
openssl s_client -connect booleanlcfg.store:443 -servername booleanlcfg.store

# Проверка конфигурации Nginx
docker exec auth_nginx_prod nginx -t
```

## 🆘 Устранение неполадок

### Частые проблемы

1. **SSL сертификаты не найдены**
   ```bash
   ls -la nginx/ssl/
   # Убедитесь, что файлы существуют и имеют правильные права
   ```

2. **Порты заняты**
   ```bash
   sudo netstat -tlnp | grep -E ':(80|443)'
   # Остановите другие сервисы, использующие эти порты
   ```

3. **DNS не настроен**
   ```bash
   nslookup booleanlcfg.store
   # Убедитесь, что домен указывает на ваш сервер
   ```

4. **Контейнеры не запускаются**
   ```bash
   docker-compose -f docker-compose.prod.yml logs
   # Проверьте логи для диагностики
   ```

### Полезные команды диагностики
```bash
# Проверка использования диска
df -h

# Проверка памяти
free -h

# Проверка процессов
ps aux | grep docker

# Проверка сетевых соединений
ss -tulpn
```

## 🔄 Обновление приложения

### Автоматическое обновление
```bash
# Остановка
docker-compose -f docker-compose.prod.yml down

# Обновление кода
git pull

# Пересборка и запуск
docker-compose -f docker-compose.prod.yml build --no-cache
docker-compose -f docker-compose.prod.yml up -d
```

### Cron задача для автоматического обновления
```bash
# Добавить в crontab (crontab -e)
0 3 * * * cd /path/to/auth-system && git pull && docker-compose -f docker-compose.prod.yml up -d --build
```

## 📈 Масштабирование

### Горизонтальное масштабирование
```bash
# Увеличение количества backend контейнеров
docker-compose -f docker-compose.prod.yml up -d --scale backend=3
```

### Вертикальное масштабирование
```bash
# Ограничение ресурсов в docker-compose.prod.yml
services:
  backend:
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '0.5'
```

## 🎯 Результат

После успешного развертывания у вас будет:

✅ **Безопасное приложение** с SSL/TLS
✅ **Высокая производительность** с Nginx
✅ **Надежная база данных** MongoDB
✅ **Полное логирование** всех операций
✅ **Автоматический restart** контейнеров
✅ **Rate limiting** для защиты от атак
✅ **Современный UI** с React
✅ **RESTful API** на Go

### Доступные URL
- **Главная страница**: https://booleanlcfg.store
- **API Health**: https://booleanlcfg.store/health
- **API Endpoints**: https://booleanlcfg.store/api/*

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `docker-compose -f docker-compose.prod.yml logs`
2. Проверьте статус: `docker-compose -f docker-compose.prod.yml ps`
3. Проверьте ресурсы: `docker stats`
4. Создайте Issue с подробным описанием проблемы 
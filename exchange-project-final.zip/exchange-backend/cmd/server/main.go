package main

import (
  "exchange-backend/internal/db"
  "exchange-backend/internal/handler"
  "exchange-backend/internal/service"
  "log"
  "net/http"
)

func main() {
  db.InitMongo()
  service.StartRateFetcher()
  http.HandleFunc("/api/orders", handler.OrderHandler)
  http.HandleFunc("/api/rates", handler.RatesHandler)
  log.Println("Backend started on :8080")
  log.Fatal(http.ListenAndServe(":8080", nil))
}

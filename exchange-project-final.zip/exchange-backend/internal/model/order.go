package model

type Order struct {
  GiveCurrency string  `json:"giveCurrency"`
  GetCurrency  string  `json:"getCurrency"`
  GiveAmount   float64 `json:"giveAmount"`
}

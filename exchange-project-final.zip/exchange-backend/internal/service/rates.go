package service

import (
  "encoding/json"
  "log"
  "net/http"
  "sync"
  "time"
)

var (
  rates      = make(map[string]float64)
  ratesMutex = sync.RWMutex{}
)

func StartRateFetcher() {
  go func() {
    for {
      fetchRates()
      time.Sleep(40 * time.Second)
    }
  }()
}

func fetchRates() {
  url := "https://api.rapira.org/open/v1/market-pairs"
  resp, err := http.Get(url)
  if err != nil {
    log.Println("Error fetching rates:", err)
    return
  }
  defer resp.Body.Close()

  var data []map[string]interface{}
  if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
    log.Println("Decode error:", err)
    return
  }

  temp := make(map[string]float64)
  for _, pair := range data {
    sym, _ := pair["symbol"].(string)
    pr, _ := pair["price"].(float64)
    if sym == "USDT_BTC" || sym == "USDT_RUB" {
      temp[sym] = pr
    }
  }

  ratesMutex.Lock()
  rates = temp
  ratesMutex.Unlock()
}

func GetRates() map[string]float64 {
  ratesMutex.RLock()
  defer ratesMutex.RUnlock()
  return rates
}

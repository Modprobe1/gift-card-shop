package handler

import (
  "context"
  "encoding/json"
  "net/http"
  "exchange-backend/internal/db"
  "exchange-backend/internal/model"
)

func OrderHandler(w http.ResponseWriter, r *http.Request) {
  if r.Method != http.MethodPost {
    http.Error(w, "Only POST allowed", http.StatusMethodNotAllowed)
    return
  }
  var order model.Order
  if err := json.NewDecoder(r.Body).Decode(&order); err != nil {
    http.Error(w, "Invalid JSON", http.StatusBadRequest)
    return
  }
  _, err := db.OrdersCollection.InsertOne(context.Background(), order)
  if err != nil {
    http.Error(w, "DB error", http.StatusInternalServerError)
    return
  }
  w.Write([]byte("Order received and saved!"))
}

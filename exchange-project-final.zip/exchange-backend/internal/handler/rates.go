package handler

import (
  "encoding/json"
  "net/http"
  "exchange-backend/internal/service"
)

func RatesHandler(w http.ResponseWriter, r *http.Request) {
  json.NewEncoder(w).Encode(service.GetRates())
}

import React,{useState,useEffect} from 'react'
import './AdvancedExchangeForm.css'
export default function AdvancedExchangeForm(){
  const [giveCurrency,setGiveCurrency]=useState('USDT')
  const [getCurrency,setGetCurrency]=useState('RUB')
  const [giveAmount,setGiveAmount]=useState('')
  const [receiveAmount,setReceiveAmount]=useState('')
  const [rate,setRate]=useState(null)
  const [minMax,setMinMax]=useState({min:1,max:10000})
  const [error,setError]=useState('')
  const [loading,setLoading]=useState(false)
  const COMM=0.03
  useEffect(()=>{
    async function f(){
      try{let res=await fetch('/api/rates'),data=await res.json(),pair=`${giveCurrency}_${getCurrency}`,r=data[pair];setRate(r);setMinMax({min:10,max:5000})}catch{}
    }
    f();const id=setInterval(f,40000);return()=>clearInterval(id)
  },[giveCurrency,getCurrency])
  useEffect(()=>{
    if(!rate||!giveAmount)return setReceiveAmount('')
    let amt=parseFloat(giveAmount)
    if(amt<minMax.min||amt>minMax.max){setError(`Допустимо от ${minMax.min} до ${minMax.max} ${giveCurrency}`);return setReceiveAmount('')}
    setError('');setReceiveAmount((amt*rate*(1-COMM)).toFixed(2))
  },[rate,giveAmount,minMax])
  async function h(e){
    e.preventDefault()
    if(error||!giveAmount)return
    setLoading(true)
    await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({giveCurrency,getCurrency,giveAmount:+giveAmount})})
    setLoading(false);alert('Заявка создана')
  }
  return (
    <form className="adv-exchange" onSubmit={h}>
      <div className="adv-section send">
        <h3>Send</h3>
        <div className="info">Exchange rate: 1 {giveCurrency} = {rate?.toFixed(4)||'...'} {getCurrency}</div>
        <div className="card"><div className="icon">💱</div><select onChange={e=>setGiveCurrency(e.target.value)} value={giveCurrency}><option>USDT</option><option>BTC</option></select></div>
        <div className="limits"><span>min:{minMax.min} {giveCurrency}</span><span>max:{minMax.max} {giveCurrency}</span></div>
        <input type="number" value={giveAmount} onChange={e=>setGiveAmount(e.target.value)} placeholder="Amount"/>
        {error&&<div className="error">{error}</div>}
      </div>
      <div className="adv-section receive">
        <h3>Receive</h3>
        <div className="card"><div className="icon">🏦</div><select onChange={e=>setGetCurrency(e.target.value)} value={getCurrency}><option>RUB</option><option>RUB_TINK</option></select></div>
        <div className="limits"><span>min:{(minMax.min*rate*(1-COMM)).toFixed(2)} {getCurrency}</span><span>max:{(minMax.max*rate*(1-COMM)).toFixed(2)} {getCurrency}</span></div>
        <input type="text" readOnly value={receiveAmount} placeholder="You receive"/>
      </div>
      <button className="adv-submit" disabled={loading||!!error}>{loading?'Processing...':'Exchange Now'}</button>
    </form>
)
}

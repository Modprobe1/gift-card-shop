
package handlers

import (
    "context"
    "net/http"
    "os"

    "github.com/gin-gonic/gin"
    "go.mongodb.org/mongo-driver/mongo"
    "go.mongodb.org/mongo-driver/mongo/options"
    "exchange-backend/models"
)

func getOrderCollection() *mongo.Collection {
    client, _ := mongo.Connect(context.TODO(), options.Client().ApplyURI(os.Getenv("MONGO_URI")))
    return client.Database("exchange_db").Collection("orders")
}

func CreateOrder(c *gin.Context) {
    var order models.Order
    if err := c.ShouldBindJSON(&order); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    collection := getOrderCollection()
    _, err := collection.InsertOne(context.TODO(), order)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Ошибка при создании заявки"})
        return
    }

    c.JSON(http.StatusCreated, gin.H{"message": "Заявка создана успешно"})
}


package handlers

import (
    "context"
    "net/http"
    "os"
    "time"

    "github.com/gin-gonic/gin"
    "go.mongodb.org/mongo-driver/bson"
    "go.mongodb.org/mongo-driver/mongo"
    "go.mongodb.org/mongo-driver/mongo/options"
    "go.mongodb.org/mongo-driver/bson/primitive"
    "golang.org/x/crypto/bcrypt"

    "exchange-backend/models"
    "exchange-backend/utils"
)

func getUserCollection() *mongo.Collection {
    client, _ := mongo.Connect(context.TODO(), options.Client().ApplyURI(os.Getenv("MONGO_URI")))
    return client.Database("exchange_db").Collection("users")
}

func Register(c *gin.Context) {
    var user models.User
    if err := c.ShouldBindJSON(&user); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    hashedPassword, _ := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost)
    user.Password = string(hashedPassword)

    collection := getUserCollection()
    _, err := collection.InsertOne(context.TODO(), user)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Ошибка при создании пользователя"})
        return
    }

    c.JSON(http.StatusCreated, gin.H{"message": "Регистрация успешна"})
}

func Login(c *gin.Context) {
    var input models.User
    if err := c.ShouldBindJSON(&input); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }

    var user models.User
    collection := getUserCollection()
    err := collection.FindOne(context.TODO(), bson.M{"email": input.Email}).Decode(&user)
    if err != nil {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "Пользователь не найден"})
        return
    }

    if bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(input.Password)) != nil {
        c.JSON(http.StatusUnauthorized, gin.H{"error": "Неверный пароль"})
        return
    }

    token, _ := utils.GenerateToken(user.ID.Hex())

    c.SetCookie("token", token, 3600*24, "/", "localhost", false, true)

    c.JSON(http.StatusOK, gin.H{"message": "Авторизация успешна"})
}

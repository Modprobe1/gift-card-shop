
package handlers

import (
    "net/http"
    "strings"

    "github.com/gin-gonic/gin"
    "exchange-backend/utils"
)

func AuthMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        tokenCookie, err := c.Cookie("token")
        if err != nil {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Не авторизован"})
            return
        }

        tokenString := strings.TrimSpace(tokenCookie)
        token, err := utils.ValidateToken(tokenString)
        if err != nil || !token.Valid {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Токен невалидный"})
            return
        }

        c.Next()
    }
}


package main

import (
    "github.com/gin-gonic/gin"
    "exchange-backend/handlers"
)

func main() {
    r := gin.Default()

    auth := r.Group("/auth")
    {
        auth.POST("/register", handlers.Register)
        auth.POST("/login", handlers.Login)
    }

    protected := r.Group("/api", handlers.AuthMiddleware())
    {
        protected.POST("/orders", handlers.CreateOrder)
    }

    r.Run(":8080")
}

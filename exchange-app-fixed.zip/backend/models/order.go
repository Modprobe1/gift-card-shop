
package models

import "go.mongodb.org/mongo-driver/bson/primitive"

type Order struct {
    ID           primitive.ObjectID `bson:"_id,omitempty"`
    UserID       primitive.ObjectID `bson:"user_id"`
    FromCurrency string             `bson:"from_currency"`
    ToCurrency   string             `bson:"to_currency"`
    Amount       float64            `bson:"amount"`
}

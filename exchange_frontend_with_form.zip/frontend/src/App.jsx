import React from 'react';
import ExchangeForm from './components/ExchangeForm';

function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
      <ExchangeForm />
    </div>
  );
}

export default App;

package main

import (
    "context"
    "fmt"
    "net/http"
    "go.mongodb.org/mongo-driver/mongo"
    "go.mongodb.org/mongo-driver/mongo/options"
)

func main() {
    client, err := mongo.Connect(context.TODO(), options.Client().ApplyURI("mongodb://mongo:27017"))
    if err != nil {
        panic(err)
    }
    defer client.Disconnect(context.TODO())

    http.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
        fmt.Fprintln(w, "Backend OK")
    })

    fmt.Println("Server running on :8080")
    http.ListenAndServe(":8080", nil)
}

package models

import "time"

type Order struct {
  ID string `json:"id" bson:"_id"`
  From string `json:"from" bson:"from"`
  To string `json:"to" bson:"to"`
  Amount float64 `json:"amount" bson:"amount"`
  Rate float64 `json:"rate" bson:"rate"`
  ReceiveAmount float64 `json:"receive_amount" bson:"receive_amount"`
  Profit float64 `json:"profit" bson:"profit"`
  IP string `json:"ip" bson:"ip"`
  UserAgent string `json:"user_agent" bson:"user_agent"`
  CreatedAt time.Time `json:"created_at" bson:"created_at"`
}

type OrderInput struct {
  From string `json:"from"`
  To string `json:"to"`
  Amount float64 `json:"amount"`
  Rate float64 `json:"rate"`
  ReceiveAmount float64 `json:"receive_amount"`
}

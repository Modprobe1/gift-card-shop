package handlers

import (
  "encoding/json"
  "net/http"
  "sync"
  "time"

  "github.com/gin-gonic/gin"
)

var (
  cachedRate float64
  rateMutex  sync.RWMutex
)

func init() {
  go updateRatePeriodically()
}

func updateRatePeriodically() {
  for {
    resp, err := http.Get("https://api.binance.com/api/v3/ticker/price?symbol=USDTRUB")
    if err == nil {
      defer resp.Body.Close()
      var data map[string]string
      if err := json.NewDecoder(resp.Body).Decode(&data); err == nil {
        if priceStr, ok := data["price"]; ok {
          var p float64
          if _, err := fmt.Sscanf(priceStr, "%f", &p); err == nil {
            rateMutex.Lock()
            cachedRate = p * 0.97 // добавляем наценку
            rateMutex.Unlock()
          }
        }
      }
    }
    time.Sleep(60 * time.Second)
  }
}

func GetUSDTtoRUBRate(c *gin.Context) {
  rateMutex.RLock()
  rate := cachedRate
  rateMutex.RUnlock()
  if rate == 0 {
    c.JSON(http.StatusServiceUnavailable, gin.H{"error": "rate not available yet"})
    return
  }
  c.JSON(http.StatusOK, gin.H{"rate": rate})
}

package handlers

import (
	"encoding/json"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Direction struct {
	From string  `json:"from"`
	To   string  `json:"to"`
	Rate float64 `json:"rate"`
}

func GetUSDTtoRUBRate(c *gin.Context) {
	resp, err := http.Get("https://api.rapira.exchange/v1/public/exchange/directions")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch rate"})
		return
	}
	defer resp.Body.Close()

	var result struct {
		Directions []Direction `json:"directions"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to decode rate"})
		return
	}

	for _, dir := range result.Directions {
		if dir.From == "USDT" && dir.To == "RUB" {
			finalRate := dir.Rate * 0.97
			c.JSON(http.StatusOK, gin.H{"rate": finalRate})
			return
		}
	}

	c.JSON(http.StatusNotFound, gin.H{"error": "direction not found"})
}

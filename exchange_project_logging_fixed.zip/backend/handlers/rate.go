package handlers

import (
  "encoding/json"
  "fmt"
  "log"
  "net/http"
  "sync"

  "github.com/gin-gonic/gin"
)

var (
  cachedRate float64
  rateMutex  sync.RWMutex
)

// FetchAndUpdateRate — ручной вызов
func FetchAndUpdateRate() {
  log.Println("[RATE] Получаем курс с Binance...")
  resp, err := http.Get("https://api.binance.com/api/v3/ticker/price?symbol=USDTRUB")
  if err != nil {
    log.Println("[RATE][ERROR] Не удалось получить курс:", err)
    return
  }
  defer resp.Body.Close()

  var data map[string]string
  if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
    log.Println("[RATE][ERROR] Ошибка разбора JSON:", err)
    return
  }

  priceStr := data["price"]
  var price float64
  if _, err := fmt.Sscanf(priceStr, "%f", &price); err != nil {
    log.Println("[RATE][ERROR] Ошибка конвертации строки:", err)
    return
  }

  rateMutex.Lock()
  cachedRate = price * 0.97 // 3% наценка
  rateMutex.Unlock()
  log.Printf("[RATE] Успешно обновлен курс: %.2f (с наценкой)", cachedRate)
}

func GetUSDTtoRUBRate(c *gin.Context) {
  rateMutex.RLock()
  rate := cachedRate
  rateMutex.RUnlock()
  if rate == 0 {
    log.Println("[RATE][WARN] Курс не инициализирован — отдаем ошибку клиенту")
    c.JSON(http.StatusServiceUnavailable, gin.H{"error": "rate not available yet"})
    return
  }
  c.JSON(http.StatusOK, gin.H{"rate": rate})
}

package handlers

import (
  "encoding/json"
  "net/http"
  "github.com/gin-gonic/gin"
)

func GetUSDTtoRUBRate(c *gin.Context) {
  resp, err := http.Get("https://api.binance.com/api/v3/ticker/price?symbol=USDTRUB")
  if err != nil {
    c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch rate"})
    return
  }
  defer resp.Body.Close()
  var data map[string]string
  if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
    c.JSON(http.StatusInternalServerError, gin.H{"error": "bad response"})
    return
  }
  price := data["price"]
  c.JSON(http.StatusOK, gin.H{"rate": price})
}

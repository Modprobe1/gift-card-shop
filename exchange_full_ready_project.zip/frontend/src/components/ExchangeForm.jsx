import { useState, useEffect } from "react";
import axios from "axios";

export default function ExchangeForm() {
  const [fromCurrency, setFromCurrency] = useState("USDT");
  const [toCurrency, setToCurrency] = useState("Сбербанк");
  const [amount, setAmount] = useState("");
  const [rate, setRate] = useState(null);
  const [calculated, setCalculated] = useState(null);
  const [profit, setProfit] = useState(null);

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const res = await axios.get("https://api.rapira.exchange/v1/public/exchange/directions");
        const directions = res.data.directions;
        const found = directions.find(d => d.from === "USDT" && d.to === "RUB");
        if (found) {
          setRate(found.rate);
        }
      } catch (err) {
        console.error("Ошибка получения курса:", err);
      }
    };
    fetchRate();
  }, []);

  useEffect(() => {
    if (rate && amount) {
      const received = (amount * rate * 0.97).toFixed(2);
      const profitValue = (amount * rate * 0.03).toFixed(2);
      setCalculated(received);
      setProfit(profitValue);
    }
  }, [rate, amount]);

  const handleSubmit = async () => {
    try {
      const payload = {
        from: fromCurrency,
        to: toCurrency,
        amount: parseFloat(amount)
      };
      await axios.post("/api/orders", payload);
      alert("Заявка отправлена");
    } catch (err) {
      alert("Ошибка при создании заявки");
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-2xl shadow-lg max-w-md w-full">
      <h2 className="text-xl font-semibold mb-4">💱 Обмен</h2>
      <div className="mb-4">
        <label className="block text-sm mb-1">Отдаете</label>
        <select value={fromCurrency} onChange={(e) => setFromCurrency(e.target.value)} className="w-full p-2 rounded bg-gray-700 text-white">
          <option value="USDT">USDT</option>
        </select>
      </div>
      <div className="mb-4">
        <label className="block text-sm mb-1">Получаете</label>
        <select value={toCurrency} onChange={(e) => setToCurrency(e.target.value)} className="w-full p-2 rounded bg-gray-700 text-white">
          <option value="Сбербанк">Сбербанк</option>
        </select>
      </div>
      <div className="mb-4">
        <label className="block text-sm mb-1">Сумма</label>
        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full p-2 rounded bg-gray-700 text-white" />
      </div>
      {calculated && (
        <div className="mb-4 text-sm text-gray-300">
          Вы получите: <strong>{calculated} RUB</strong><br />
          Профит сервиса: <strong>{profit} RUB</strong>
        </div>
      )}
      <button onClick={handleSubmit} className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded w-full">Обменять</button>
    </div>
  );
}
